package com.zjy.util;

public class util {

    public static void print(String a) {
        System.out.println(a);
    }
    public static void print(int a) {
        System.out.println(a);
    }
    public static void print(short a) {
        System.out.println(a);
    }
    public static void print(long a) {
        System.out.println(a);
    }
    public static void print(double a) {
        System.out.println(a);
    }
    public static void print(byte a) {
        System.out.println(a);
    }
    public static void print(float a) {
        System.out.println(a);
    }
    public static void print(char a) {
        System.out.println(a);
    }
    public static void print(boolean a) {
        System.out.println(a);
    }

    public static void print() {
    }

}